
import os
import logging
from datetime import datetime
import requests
from flask import Flask, request, jsonify
import yfinance as yf
import feedparser

# --- OpenAI (new SDK) ---
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except Exception:
    OPENAI_AVAILABLE = False

# ---------- Config ----------
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")  # string or int
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

assert TELEGRAM_TOKEN, "Missing TELEGRAM_TOKEN env var"
assert CHAT_ID, "Missing CHAT_ID env var"
assert OPENAI_API_KEY, "Missing OPENAI_API_KEY env var"

# Create OpenAI client if library available
client = None
if OPENAI_AVAILABLE:
    client = OpenAI(api_key=OPENAI_API_KEY)

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

def send_telegram_message(text: str):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text}
    try:
        r = requests.post(url, json=payload, timeout=20)
        r.raise_for_status()
    except Exception as e:
        app.logger.error(f"Telegram send error: {e}")
        return False
    return True

def fetch_price(symbol: str):
    try:
        hist = yf.Ticker(symbol).history(period="1d", interval="1m").tail(1)
        if not hist.empty:
            return round(float(hist["Close"].iloc[-1]), 2)
    except Exception as e:
        app.logger.error(f"Price fetch error for {symbol}: {e}")
    return None

def fetch_top_news(limit=3):
    feeds = [
        "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
        "https://www.moneycontrol.com/rss/MCtopnews.xml",
    ]
    items = []
    for url in feeds:
        try:
            d = feedparser.parse(url)
            for e in d.entries[:limit]:
                title = getattr(e, "title", "").strip()
                if title and title not in items:
                    items.append(title)
        except Exception as e:
            app.logger.error(f"News fetch error: {e}")
    return items[:limit]

def get_fii_dii_summary():
    """
    Placeholder: Reliable free API for FII/DII fluctuates.
    We attempt NSE press releases later; for now return 'N/A'.
    """
    try:
        # TODO: Replace with a stable API/source when available.
        return "FII/DII: Data source not configured (add later)."
    except Exception as e:
        app.logger.error(f"FII-DII fetch error: {e}")
        return "FII/DII: unavailable"

def ai_market_summary(nifty, banknifty, news_list):
    if not client:
        return "AI not available (OpenAI SDK missing)."

    news_bullets = "\n".join([f"• {t}" for t in news_list]) if news_list else "• No major headlines."
    prompt = f"""
You are a disciplined intraday trading assistant for India markets.
Data:
- Nifty spot: {nifty}
- Bank Nifty spot: {banknifty}
Headlines:
{news_bullets}

Task:
1) Give a crisp directional bias (Bullish/Bearish/Neutral).
2) 2 scalping levels for Nifty (if > then long, if < then short) with tight invalidation.
3) 2 scalping levels for Bank Nifty.
4) Very brief risk note (max 1 line).

Reply in simple Hinglish + a few emojis. Keep it short.
"""

    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt.strip()}],
            temperature=0.2,
            max_tokens=300,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        app.logger.error(f"OpenAI error: {e}")
        return "AI summary unavailable (OpenAI error)."

@app.get("/health")
def health():
    return {"ok": True, "ts": datetime.utcnow().isoformat()}

@app.get("/update")
def update_all():
    # Fetch data
    nse = fetch_price("^NSEI")
    bank = fetch_price("^NSEBANK")
    news = fetch_top_news(limit=3)
    fii = get_fii_dii_summary()

    # Compose message
    header = "🟢 Market Radar (Auto)\n"
    prices = f"Nifty: {nse if nse else 'NA'} | BankNifty: {bank if bank else 'NA'}"
    headlines = "📰 Top Headlines:\n" + ("\n".join([f"- {t}" for t in news]) if news else "- No headlines")
    ai = ai_market_summary(nse, bank, news)
    msg = f"{header}{prices}\n{headlines}\n\n{fii}\n\n🤖 AI View:\n{ai}"

    ok = send_telegram_message(msg)
    return jsonify({"sent": ok})

@app.post("/signal")
def manual_signal():
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return {"error": "send JSON {text: '...'}"}, 400
    ok = send_telegram_message(f"⚡ Signal: {text}")
    return {"sent": ok}

# Morning & Evening split (for Render Cron)
@app.get("/cron/morning")
def cron_morning():
    nse = fetch_price("^NSEI")
    bank = fetch_price("^NSEBANK")
    news = fetch_top_news(limit=5)
    msg = "🌅 Morning Brief\n"
    msg += f"Nifty: {nse if nse else 'NA'} | BankNifty: {bank if bank else 'NA'}\n"
    msg += "📰 Headlines:\n" + ("\n".join([f"- {t}" for t in news]) if news else "- No headlines")
    ok = send_telegram_message(msg)
    return jsonify({"sent": ok})

@app.get("/cron/evening")
def cron_evening():
    fii = get_fii_dii_summary()
    ok = send_telegram_message(f"🌇 Closing Brief\n{fii}\nNote: Add P&L & sector heatmap later.")
    return jsonify({"sent": ok})

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
