
# Market AI Bot (Render-ready)

This service sends auto market updates and AI summaries to your Telegram.

## Environment Variables (set these in Render → Environment)
- `TELEGRAM_TOKEN` – your Telegram bot token
- `CHAT_ID` – your Telegram numeric chat id (e.g., 5270905764)
- `OPENAI_API_KEY` – your OpenAI API key

## Endpoints
- `GET /health` – check service health
- `GET /update` – fetch prices + headlines + AI summary and send to Telegram
- `GET /cron/morning` – morning brief (use Render Cron at 03:00 UTC = 08:30 IST)
- `GET /cron/evening` – evening brief (use Render Cron at 12:00 UTC = 17:30 IST)
- `POST /signal` – send manual signal to Telegram, JSON: `{ "text": "Nifty above 22500 buy CE" }`

## Deploy (Quick)
1. Create a new repo with `app.py` and `requirements.txt`.
2. Connect on Render → New → Web Service → pick the repo.
3. Start command: `python app.py`
4. Set env vars and Deploy.
5. Test `/health` in the Render URL.

## Cron Jobs in Render
Create two cron jobs:
- Morning: `GET https://<your>.onrender.com/cron/morning` at 03:00 UTC daily
- Evening: `GET https://<your>.onrender.com/cron/evening` at 12:00 UTC daily

